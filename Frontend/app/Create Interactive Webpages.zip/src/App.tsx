import { useState } from 'react'

// ─── Types ───────────────────────────────────────────────────────────────────
type Page =
  | 'dashboard'
  | 'rentals'
  | 'rental-details'
  | 'gear'
  | 'gear-details'
  | 'add-gear'
  | 'edit-gear'
  | 'users'
  | 'categories'
  | 'reports'

type RentalStatus = 'Trip Reserved' | 'Active' | 'Due Soon' | 'Overdue' | 'Returned'
type GearStatus = 'Available' | 'Rented' | 'Maintenance' | 'Inactive'
type UserRole = 'Student' | 'Staff' | 'Admin'
type UserStatus = 'Active' | 'Inactive'
type AccessLevel = 'Everyone' | 'Staff only'

interface User {
  id: number
  name: string
  email: string
  role: UserRole
  status: UserStatus
  rentals: number
  joined: string
}

interface Category {
  id: number
  name: string
  description: string
  itemCount: number
  icon: string
  subcategories: string[]
}

interface Rental {
  id: number
  student: string
  gear: string
  checkoutDate: string
  dueDate: string
  status: RentalStatus
  durationDays: number
  access: AccessLevel
}

interface Gear {
  id: number
  name: string
  category: string
  subcategory: string
  size: string
  purchaseDate: string
  condition: string
  status: GearStatus
  description: string
  access: AccessLevel
}

// ─── Mock Data ───────────────────────────────────────────────────────────────
const initialRentals: Rental[] = [
  { id: 1, student: 'Maya K.', gear: 'Tent #14', checkoutDate: 'Sept 13', dueDate: 'Sept 20', status: 'Active', durationDays: 7, access: 'Everyone' },
  { id: 2, student: 'Jordan T.', gear: 'Backpack #08', checkoutDate: 'Sept 11', dueDate: 'Sept 18', status: 'Due Soon', durationDays: 7, access: 'Everyone' },
  { id: 3, student: 'Alex R.', gear: 'Sleeping Bag', checkoutDate: 'Sept 10', dueDate: 'Sept 17', status: 'Overdue', durationDays: 7, access: 'Everyone' },
  { id: 4, student: 'Taylor S.', gear: 'Kayak #03', checkoutDate: 'Sept 8', dueDate: 'Sept 15', status: 'Overdue', durationDays: 7, access: 'Everyone' },
  { id: 5, student: 'Jamie L.', gear: 'Tent #15', checkoutDate: 'Sept 5', dueDate: 'Sept 12', status: 'Returned', durationDays: 7, access: 'Everyone' },
  { id: 6, student: 'Sam W.', gear: 'Stove #07', checkoutDate: 'Sept 1', dueDate: 'Sept 4', status: 'Returned', durationDays: 3, access: 'Everyone' },
  { id: 7, student: 'Chris M.', gear: 'Tent #14', checkoutDate: 'Sept 24', dueDate: 'Sept 29', status: 'Trip Reserved', durationDays: 5, access: 'Staff only' },
  { id: 8, student: 'Jordan T.', gear: 'Tent #14', checkoutDate: 'Aug 20', dueDate: 'Aug 27', status: 'Returned', durationDays: 7, access: 'Everyone' },
  { id: 9, student: 'Maya K.', gear: 'Backpack #08', checkoutDate: 'Aug 12', dueDate: 'Aug 17', status: 'Returned', durationDays: 5, access: 'Everyone' },
]

const initialUsers: User[] = [
  { id: 1, name: 'Maya K.', email: 'maya.k@school.edu', role: 'Student', status: 'Active', rentals: 4, joined: 'Aug 2026' },
  { id: 2, name: 'Jordan T.', email: 'jordan.t@school.edu', role: 'Student', status: 'Active', rentals: 7, joined: 'Aug 2026' },
  { id: 3, name: 'Alex R.', email: 'alex.r@school.edu', role: 'Student', status: 'Active', rentals: 2, joined: 'Sep 2026' },
  { id: 4, name: 'Taylor S.', email: 'taylor.s@school.edu', role: 'Student', status: 'Active', rentals: 5, joined: 'Aug 2026' },
  { id: 5, name: 'Jamie L.', email: 'jamie.l@school.edu', role: 'Student', status: 'Inactive', rentals: 1, joined: 'Jul 2026' },
  { id: 6, name: 'Sam W.', email: 'sam.w@school.edu', role: 'Student', status: 'Active', rentals: 3, joined: 'Aug 2026' },
  { id: 7, name: 'Chris M.', email: 'chris.m@school.edu', role: 'Staff', status: 'Active', rentals: 0, joined: 'Jan 2025' },
  { id: 8, name: 'Dana P.', email: 'dana.p@school.edu', role: 'Admin', status: 'Active', rentals: 0, joined: 'Jan 2024' },
]

const initialCategories: Category[] = [
  { id: 1, name: 'Camping', description: 'Tents, sleeping bags, tarps, and shelter equipment.', itemCount: 12, icon: '⛺', subcategories: ['Tents', 'Sleep Systems', 'Shelter'] },
  { id: 2, name: 'Hiking', description: 'Backpacks, trekking poles, and trail essentials.', itemCount: 8, icon: '🥾', subcategories: ['Backpacks', 'Trekking Poles'] },
  { id: 3, name: 'Water Sports', description: 'Kayaks, canoes, paddles, and life vests.', itemCount: 5, icon: '🚣', subcategories: ['Kayaks', 'Safety Gear'] },
  { id: 4, name: 'Cooking', description: 'Camp stoves, cookware, and food storage.', itemCount: 9, icon: '🍳', subcategories: ['Stoves', 'Cookware'] },
  { id: 5, name: 'Climbing', description: 'Harnesses, ropes, carabiners, and helmets.', itemCount: 6, icon: '🧗', subcategories: ['Protection', 'Ropes'] },
  { id: 6, name: 'Navigation', description: 'Compasses, maps, and GPS devices.', itemCount: 4, icon: '🧭', subcategories: ['Maps', 'GPS'] },
]

const initialGear: Gear[] = [
  { id: 1, name: 'Tent #14', category: 'Camping', subcategory: 'Tents', size: '2-Person', purchaseDate: 'Jan 5, 2024', condition: 'Good', status: 'Rented', description: 'Compact 2-person tent, great for weekend trips.', access: 'Everyone' },
  { id: 2, name: 'Tent #15', category: 'Camping', subcategory: 'Tents', size: '4-Person', purchaseDate: 'Jan 15, 2024', condition: 'Good', status: 'Available', description: 'Spacious 4-person tent, great for group trips.', access: 'Everyone' },
  { id: 3, name: 'Backpack #08', category: 'Hiking', subcategory: 'Backpacks', size: 'Medium', purchaseDate: 'Feb 3, 2024', condition: 'Good', status: 'Rented', description: '65L hiking backpack with frame support.', access: 'Everyone' },
  { id: 4, name: 'Kayak #03', category: 'Water Sports', subcategory: 'Kayaks', size: '—', purchaseDate: 'Mar 10, 2023', condition: 'Good', status: 'Available', description: 'Single-person sea kayak with paddle.', access: 'Staff only' },
  { id: 5, name: 'Stove #07', category: 'Cooking', subcategory: 'Stoves', size: '—', purchaseDate: 'Jan 5, 2024', condition: 'Needs Repair', status: 'Inactive', description: 'Portable camping stove. Currently not working and needs repair.', access: 'Everyone' },
  { id: 6, name: 'Sleeping Bag', category: 'Camping', subcategory: 'Sleep Systems', size: 'Standard', purchaseDate: 'Dec 1, 2023', condition: 'Fair', status: 'Rented', description: 'Rated to 20°F, suitable for three-season use.', access: 'Everyone' },
]

const itemType = (name: string) => name.replace(/\s+#\d+$/, '')

// ─── Status Badges ────────────────────────────────────────────────────────────
function RentalBadge({ status }: { status: RentalStatus }) {
  const styles: Record<RentalStatus, string> = {
    'Trip Reserved': 'bg-purple-100 text-purple-800 border-purple-200',
    Active: 'bg-green-100 text-green-800 border-green-200',
    'Due Soon': 'bg-yellow-100 text-yellow-800 border-yellow-200',
    Overdue: 'bg-red-100 text-red-800 border-red-200',
    Returned: 'bg-gray-100 text-gray-600 border-gray-200',
  }
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium border font-mono ${styles[status]}`}>
      {status}
    </span>
  )
}

function GearBadge({ status }: { status: GearStatus }) {
  const styles: Record<GearStatus, string> = {
    Available: 'bg-green-100 text-green-800 border-green-200',
    Rented: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    Maintenance: 'bg-blue-100 text-blue-800 border-blue-200',
    Inactive: 'bg-gray-100 text-gray-500 border-gray-200',
  }
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium border font-mono ${styles[status]}`}>
      {status}
    </span>
  )
}

// ─── Tent SVG Illustration ────────────────────────────────────────────────────
function TentIllustration({ size = 80 }: { size?: number }) {
  return (
    <svg width={size} height={size * 0.75} viewBox="0 0 120 90" fill="none" xmlns="http://www.w3.org/2000/svg">
      <polygon points="60,5 5,85 115,85" fill="#52b788" stroke="#2d6a4f" strokeWidth="2" />
      <polygon points="60,5 35,85 85,85" fill="#40916c" />
      <rect x="42" y="62" width="36" height="23" rx="2" fill="#1b4332" />
      <ellipse cx="60" cy="62" rx="18" ry="8" fill="#1b4332" />
      <line x1="60" y1="5" x2="60" y2="0" stroke="#2d6a4f" strokeWidth="2" />
      <circle cx="60" cy="0" r="2" fill="#2d6a4f" />
    </svg>
  )
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────
const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: '⊞' },
  { id: 'rentals', label: 'Rentals', icon: '≡' },
  { id: 'gear', label: 'Gear', icon: '▲' },
  { id: 'users', label: 'Users', icon: '●●' },
  { id: 'categories', label: 'Categories', icon: '⬡' },
  { id: 'reports', label: 'Reports', icon: '⟊' },
]

function Sidebar({ page, navigate }: { page: Page; navigate: (p: Page) => void }) {
  const activePage = page === 'rental-details' ? 'rentals' :
    page === 'gear-details' || page === 'add-gear' || page === 'edit-gear' ? 'gear' : page

  return (
    <aside className="w-44 bg-white border-r border-gray-200 flex flex-col shrink-0 min-h-screen">
      <nav className="flex flex-col pt-4 gap-0.5 px-2">
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => navigate(item.id as Page)}
            className={`flex items-center gap-3 px-3 py-2.5 rounded text-sm font-medium transition-colors text-left w-full cursor-pointer
              ${activePage === item.id
                ? 'bg-green-700 text-white'
                : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
          >
            <span className="text-base leading-none">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
    </aside>
  )
}

// ─── Header ───────────────────────────────────────────────────────────────────
function Header() {
  const openSchema = () => {
    window.open(`${window.location.pathname}?view=schema`, '_blank', 'noopener,noreferrer')
  }

  return (
    <header className="h-14 bg-white border-b border-gray-200 flex items-center justify-between px-6 shrink-0">
      <div className="flex items-center gap-3">
        <TentIllustration size={32} />
        <span className="font-bold text-sm tracking-widest uppercase text-gray-800">Outdoor Adventures</span>
      </div>
      <div className="flex items-center gap-4">
        <button
          onClick={openSchema}
          className="text-xs font-semibold text-green-700 border border-green-200 bg-green-50 hover:bg-green-100 px-3 py-1.5 rounded transition-colors cursor-pointer"
        >
          Data Schema ↗
        </button>
        <button className="flex items-center gap-2 text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors cursor-pointer">
          Staff
          <span className="text-xs">▼</span>
        </button>
      </div>
    </header>
  )
}

// ─── Layout ───────────────────────────────────────────────────────────────────
function Layout({ page, navigate, children }: { page: Page; navigate: (p: Page) => void; children: React.ReactNode }) {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />
      <div className="flex flex-1">
        <Sidebar page={page} navigate={navigate} />
        <main className="flex-1 p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  )
}

// ─── Page: Dashboard ──────────────────────────────────────────────────────────
function DashboardPage({ rentals, navigate }: { rentals: Rental[]; navigate: (p: Page, id?: number) => void }) {
  const reserved = rentals.filter(r => r.status === 'Trip Reserved').length
  const active = rentals.filter(r => r.status === 'Active').length
  const dueSoon = rentals.filter(r => r.status === 'Due Soon').length
  const overdue = rentals.filter(r => r.status === 'Overdue').length
  const recent = rentals.slice(0, 3)

  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Dashboard</h1>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 text-center">
          <div className="text-3xl font-bold text-purple-800 font-mono">{reserved}</div>
          <div className="text-sm text-purple-700 mt-1 font-medium">Trip Reserved</div>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
          <div className="text-3xl font-bold text-green-800 font-mono">{active}</div>
          <div className="text-sm text-green-700 mt-1 font-medium">Active Rentals</div>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-center">
          <div className="text-3xl font-bold text-yellow-800 font-mono">{dueSoon}</div>
          <div className="text-sm text-yellow-700 mt-1 font-medium">Due Soon</div>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
          <div className="text-3xl font-bold text-red-800 font-mono">{overdue}</div>
          <div className="text-sm text-red-700 mt-1 font-medium">Overdue Rentals</div>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <h2 className="font-semibold text-gray-800">Recent Rentals</h2>
          <button onClick={() => navigate('rentals')} className="text-sm text-green-700 hover:text-green-900 font-medium cursor-pointer">
            View all →
          </button>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider">
              <th className="text-left px-5 py-3 font-medium">Student</th>
              <th className="text-left px-5 py-3 font-medium">Gear</th>
              <th className="text-left px-5 py-3 font-medium">Due Date</th>
              <th className="text-left px-5 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {recent.map((r, i) => (
              <tr
                key={r.id}
                onClick={() => navigate('rental-details', r.id)}
                className={`cursor-pointer hover:bg-green-50 transition-colors ${i < recent.length - 1 ? 'border-b border-gray-100' : ''}`}
              >
                <td className="px-5 py-3 font-medium text-gray-800">{r.student}</td>
                <td className="px-5 py-3 text-gray-600">{r.gear}</td>
                <td className="px-5 py-3 text-gray-600 font-mono text-xs">{r.dueDate}</td>
                <td className="px-5 py-3"><RentalBadge status={r.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ─── Page: Rentals ────────────────────────────────────────────────────────────
type RentalFilter = 'All' | RentalStatus

function RentalsPage({ rentals, navigate }: { rentals: Rental[]; navigate: (p: Page, id?: number) => void }) {
  const [filter, setFilter] = useState<RentalFilter>('All')
  const [accessFilter, setAccessFilter] = useState<'All' | AccessLevel>('All')
  const [search, setSearch] = useState('')

  const filters: RentalFilter[] = ['All', 'Trip Reserved', 'Active', 'Due Soon', 'Overdue', 'Returned']
  const filtered = rentals.filter(r => {
    const matchFilter = filter === 'All' || r.status === filter
    const matchAccess = accessFilter === 'All' || r.access === accessFilter
    const matchSearch = r.student.toLowerCase().includes(search.toLowerCase()) ||
      r.gear.toLowerCase().includes(search.toLowerCase())
    return matchFilter && matchAccess && matchSearch
  })

  return (
    <div className="max-w-4xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Rentals</h1>
        <button
          onClick={() => navigate('add-gear')}
          className="flex items-center gap-2 bg-green-700 hover:bg-green-800 text-white text-sm font-medium px-4 py-2 rounded transition-colors cursor-pointer"
        >
          + New Rental
        </button>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg">
        <div className="p-4 border-b border-gray-100 flex items-center gap-3 flex-wrap">
          <input
            type="text"
            placeholder="Search student or gear..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="border border-gray-200 rounded px-3 py-1.5 text-sm flex-1 min-w-48 focus:outline-none focus:ring-2 focus:ring-green-300"
          />
          <div className="flex gap-1">
            {filters.map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer
                  ${filter === f ? 'bg-green-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                {f}
              </button>
            ))}
          </div>
          <select
            value={accessFilter}
            onChange={e => setAccessFilter(e.target.value as 'All' | AccessLevel)}
            className="border border-gray-200 rounded px-3 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-green-300"
          >
            <option>All</option>
            <option>Everyone</option>
            <option>Staff only</option>
          </select>
        </div>

        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider">
              <th className="text-left px-5 py-3 font-medium">Student</th>
              <th className="text-left px-5 py-3 font-medium">Gear</th>
              <th className="text-left px-5 py-3 font-medium">Checkout</th>
              <th className="text-left px-5 py-3 font-medium">Due</th>
              <th className="text-left px-5 py-3 font-medium">Access</th>
              <th className="text-left px-5 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-5 py-8 text-center text-gray-400 text-sm">No rentals found</td>
              </tr>
            ) : filtered.map((r, i) => (
              <tr
                key={r.id}
                onClick={() => navigate('rental-details', r.id)}
                className={`cursor-pointer hover:bg-green-50 transition-colors ${i < filtered.length - 1 ? 'border-b border-gray-100' : ''}`}
              >
                <td className="px-5 py-3 font-medium text-gray-800">{r.student}</td>
                <td className="px-5 py-3 text-gray-600">{r.gear}</td>
                <td className="px-5 py-3 text-gray-500 font-mono text-xs">{r.checkoutDate}</td>
                <td className="px-5 py-3 text-gray-500 font-mono text-xs">{r.dueDate}</td>
                <td className="px-5 py-3 text-xs text-gray-500">{r.access}</td>
                <td className="px-5 py-3"><RentalBadge status={r.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ─── Page: Rental Details ─────────────────────────────────────────────────────
function RentalDetailsPage({
  rental, navigate, onMarkReturned
}: {
  rental: Rental
  navigate: (p: Page, id?: number) => void
  onMarkReturned: (id: number) => void
}) {
  const [showConfirm, setShowConfirm] = useState(false)

  const handleReturn = () => {
    onMarkReturned(rental.id)
    setShowConfirm(false)
    navigate('rentals')
  }

  return (
    <div className="max-w-xl">
      <button
        onClick={() => navigate('rentals')}
        className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-800 mb-5 transition-colors cursor-pointer"
      >
        ← Back to Rentals
      </button>

      <h1 className="text-2xl font-bold text-gray-900 mb-6">Rental Details</h1>

      <div className="bg-white border border-gray-200 rounded-lg p-6 space-y-5">
        <div className="flex items-start gap-4">
          <div className="flex-1 space-y-4">
            <div>
              <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">Student</div>
              <div className="flex items-center gap-2">
                <span className="text-lg">👤</span>
                <span className="font-semibold text-gray-800">{rental.student}</span>
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">Gear</div>
              <div className="flex items-center gap-2">
                <span className="text-lg">▲</span>
                <span className="font-semibold text-gray-800">{rental.gear}</span>
              </div>
            </div>
          </div>
          <div className="w-20 h-20 flex items-center justify-center bg-green-50 rounded-lg border border-green-100">
            <TentIllustration size={56} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 pt-2 border-t border-gray-100">
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">📅 Checkout Date</div>
            <div className="text-sm font-medium text-gray-700">{rental.checkoutDate}, 2026</div>
          </div>
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">📅 Due Date</div>
            <div className="text-sm font-medium text-gray-700">{rental.dueDate}, 2026</div>
          </div>
        </div>

        <div className="pt-2 border-t border-gray-100">
          <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-2">Status</div>
          <RentalBadge status={rental.status} />
        </div>
        <div className="pt-2 border-t border-gray-100 grid grid-cols-2 gap-4">
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">Duration</div>
            <div className="text-sm font-medium text-gray-700">{rental.durationDays} days</div>
          </div>
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">Access</div>
            <div className="text-sm font-medium text-gray-700">{rental.access}</div>
          </div>
        </div>
      </div>

      {rental.status !== 'Returned' && (
        <div className="flex gap-3 mt-5">
          <button
            onClick={() => setShowConfirm(true)}
            className="bg-green-700 hover:bg-green-800 text-white text-sm font-medium px-5 py-2.5 rounded transition-colors cursor-pointer"
          >
            Mark as Returned
          </button>
          <button className="border border-gray-300 hover:border-gray-400 text-gray-700 text-sm font-medium px-5 py-2.5 rounded transition-colors cursor-pointer">
            Edit Rental
          </button>
        </div>
      )}

      {showConfirm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600 text-xl">⚠</div>
              <button onClick={() => setShowConfirm(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer">✕</button>
            </div>
            <h3 className="font-bold text-gray-900 mb-2">Mark as Returned?</h3>
            <p className="text-sm text-gray-600 mb-5">
              Are you sure you want to mark <strong>{rental.gear}</strong> as returned for {rental.student}?
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowConfirm(false)}
                className="flex-1 border border-gray-300 text-gray-700 text-sm font-medium py-2 rounded hover:bg-gray-50 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleReturn}
                className="flex-1 bg-green-700 hover:bg-green-800 text-white text-sm font-medium py-2 rounded transition-colors cursor-pointer"
              >
                Yes, Mark Returned
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Page: Gear Inventory ─────────────────────────────────────────────────────
type GearFilter = 'All' | GearStatus

function GearPage({ gear, navigate }: { gear: Gear[]; navigate: (p: Page, id?: number) => void }) {
  const [filter, setFilter] = useState<GearFilter>('All')
  const [accessFilter, setAccessFilter] = useState<'All' | AccessLevel>('All')
  const [search, setSearch] = useState('')

  const filters: GearFilter[] = ['All', 'Available', 'Rented', 'Maintenance', 'Inactive']
  const filtered = gear.filter(g => {
    const matchFilter = filter === 'All' || g.status === filter
    const matchAccess = accessFilter === 'All' || g.access === accessFilter
    const matchSearch = g.name.toLowerCase().includes(search.toLowerCase()) ||
      g.category.toLowerCase().includes(search.toLowerCase())
    return matchFilter && matchAccess && matchSearch
  })

  return (
    <div className="max-w-4xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Gear Inventory</h1>
        <button
          onClick={() => navigate('add-gear')}
          className="flex items-center gap-2 bg-green-700 hover:bg-green-800 text-white text-sm font-medium px-4 py-2 rounded transition-colors cursor-pointer"
        >
          + Add Gear
        </button>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg">
        <div className="p-4 border-b border-gray-100 flex items-center gap-3 flex-wrap">
          <input
            type="text"
            placeholder="Search gear..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="border border-gray-200 rounded px-3 py-1.5 text-sm flex-1 min-w-40 focus:outline-none focus:ring-2 focus:ring-green-300"
          />
          <div className="flex gap-1 flex-wrap">
            {filters.map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer
                  ${filter === f ? 'bg-green-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                {f}
              </button>
            ))}
          </div>
          <select
            value={accessFilter}
            onChange={e => setAccessFilter(e.target.value as 'All' | AccessLevel)}
            className="border border-gray-200 rounded px-3 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-green-300"
          >
            <option>All</option>
            <option>Everyone</option>
            <option>Staff only</option>
          </select>
        </div>

        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider">
              <th className="text-left px-5 py-3 font-medium">Gear</th>
              <th className="text-left px-5 py-3 font-medium">Category</th>
              <th className="text-left px-5 py-3 font-medium">Subcategory</th>
              <th className="text-left px-5 py-3 font-medium">Size</th>
              <th className="text-left px-5 py-3 font-medium">Access</th>
              <th className="text-left px-5 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-5 py-8 text-center text-gray-400 text-sm">No gear found</td>
              </tr>
            ) : filtered.map((g, i) => (
              <tr
                key={g.id}
                onClick={() => navigate('gear-details', g.id)}
                className={`cursor-pointer hover:bg-green-50 transition-colors ${i < filtered.length - 1 ? 'border-b border-gray-100' : ''}`}
              >
                <td className="px-5 py-3 font-medium text-gray-800">{g.name}</td>
                <td className="px-5 py-3 text-gray-600">{g.category}</td>
                <td className="px-5 py-3 text-gray-500">{g.subcategory}</td>
                <td className="px-5 py-3 text-gray-500 font-mono text-xs">{g.size}</td>
                <td className="px-5 py-3 text-gray-500 text-xs">{g.access}</td>
                <td className="px-5 py-3"><GearBadge status={g.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ─── Page: Gear Details ───────────────────────────────────────────────────────
function GearDetailsPage({
  gearItem, navigate
}: {
  gearItem: Gear
  navigate: (p: Page, id?: number) => void
}) {
  return (
    <div className="max-w-xl">
      <button
        onClick={() => navigate('gear')}
        className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-800 mb-5 transition-colors cursor-pointer"
      >
        ← Back to Gear
      </button>

      <h1 className="text-2xl font-bold text-gray-900 mb-6">Gear Details</h1>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-start gap-6 mb-6">
          <div className="w-24 h-24 bg-green-50 rounded-lg border border-green-100 flex items-center justify-center shrink-0">
            <TentIllustration size={64} />
          </div>
          <div className="flex-1">
            <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">Name</div>
            <div className="text-xl font-bold text-gray-900 mb-3">{gearItem.name}</div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-0.5">Category</div>
                <div className="text-gray-700">{gearItem.category}</div>
              </div>
              <div>
                <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-0.5">Size</div>
                <div className="text-gray-700">{gearItem.size}</div>
              </div>
              <div>
                <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-0.5">Subcategory</div>
                <div className="text-gray-700">{gearItem.subcategory}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 border-t border-gray-100 pt-4 mb-4 text-sm">
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">Purchase Date</div>
            <div className="text-gray-700">{gearItem.purchaseDate}</div>
          </div>
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">Condition</div>
            <div className="text-gray-700">{gearItem.condition}</div>
          </div>
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">Status</div>
            <GearBadge status={gearItem.status} />
          </div>
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">Access</div>
            <div className="text-gray-700">{gearItem.access}</div>
          </div>
        </div>

        <div className="border-t border-gray-100 pt-4">
          <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">Description</div>
          <p className="text-sm text-gray-600">{gearItem.description}</p>
        </div>
      </div>

      <button
        onClick={() => navigate('edit-gear', gearItem.id)}
        className="mt-5 bg-green-700 hover:bg-green-800 text-white text-sm font-medium px-5 py-2.5 rounded transition-colors cursor-pointer"
      >
        Edit Gear
      </button>
    </div>
  )
}

// ─── Page: Add Gear ───────────────────────────────────────────────────────────
function AddGearPage({ navigate, onAdd }: { navigate: (p: Page, id?: number) => void; onAdd: (g: Omit<Gear, 'id'>) => void }) {
  const [form, setForm] = useState({
    name: '', category: '', subcategory: '', size: '', purchaseDate: '',
    condition: 'Good', status: 'Available' as GearStatus, description: '', access: 'Everyone' as AccessLevel
  })
  const [success, setSuccess] = useState(false)

  const handleSubmit = () => {
    if (!form.name || !form.category) return
    onAdd({ ...form, status: form.status as GearStatus })
    setSuccess(true)
    setTimeout(() => navigate('gear'), 1500)
  }

  if (success) {
    return (
      <div className="max-w-sm mx-auto mt-20 bg-white border border-gray-200 rounded-xl p-8 text-center shadow-sm">
        <div className="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 text-green-600 text-2xl">✓</div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">Gear Added!</h2>
        <p className="text-sm text-gray-500">{form.name} has been added to inventory.</p>
      </div>
    )
  }

  return (
    <div className="max-w-xl">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Add New Gear</h1>

      <div className="bg-white border border-gray-200 rounded-lg p-6 space-y-4">
        <div>
          <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Name *</label>
          <input
            type="text"
            placeholder="e.g., Sleeping Bag"
            value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })}
            className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Category *</label>
            <select
              value={form.category}
              onChange={e => setForm({ ...form, category: e.target.value })}
              className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300 bg-white"
            >
              <option value="">Select category...</option>
              <option>Camping</option>
              <option>Hiking</option>
              <option>Water Sports</option>
              <option>Cooking</option>
              <option>Climbing</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Subcategory</label>
            <input
              type="text"
              placeholder="e.g., Tents"
              value={form.subcategory}
              onChange={e => setForm({ ...form, subcategory: e.target.value })}
              className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Subcategory</label>
            <input
              type="text"
              value={form.subcategory}
              onChange={e => setForm({ ...form, subcategory: e.target.value })}
              className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Size</label>
            <input
              type="text"
              placeholder="e.g., Medium"
              value={form.size}
              onChange={e => setForm({ ...form, size: e.target.value })}
              className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
          <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Purchase Date</label>
          <input
            type="date"
            value={form.purchaseDate}
            onChange={e => setForm({ ...form, purchaseDate: e.target.value })}
            className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
          />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Access</label>
            <select
              value={form.access}
              onChange={e => setForm({ ...form, access: e.target.value as AccessLevel })}
              className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300 bg-white"
            >
              <option>Everyone</option>
              <option>Staff only</option>
            </select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Condition</label>
            <select
              value={form.condition}
              onChange={e => setForm({ ...form, condition: e.target.value })}
              className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300 bg-white"
            >
              <option>Excellent</option>
              <option>Good</option>
              <option>Fair</option>
              <option>Needs Repair</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Status *</label>
            <select
              value={form.status}
              onChange={e => setForm({ ...form, status: e.target.value as GearStatus })}
              className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300 bg-white"
            >
              <option>Available</option>
              <option>Maintenance</option>
              <option>Inactive</option>
            </select>
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Description</label>
          <textarea
            placeholder="Enter details about the gear..."
            value={form.description}
            onChange={e => setForm({ ...form, description: e.target.value })}
            rows={3}
            className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300 resize-none"
          />
        </div>
      </div>

      <div className="flex gap-3 mt-5">
        <button
          onClick={() => navigate('gear')}
          className="border border-gray-300 hover:border-gray-400 text-gray-700 text-sm font-medium px-5 py-2.5 rounded transition-colors cursor-pointer"
        >
          Cancel
        </button>
        <button
          onClick={handleSubmit}
          className="bg-green-700 hover:bg-green-800 text-white text-sm font-medium px-5 py-2.5 rounded transition-colors cursor-pointer"
        >
          Add Gear
        </button>
      </div>
    </div>
  )
}

// ─── Page: Edit Gear ──────────────────────────────────────────────────────────
function EditGearPage({
  gearItem, navigate, onSave, onDelete
}: {
  gearItem: Gear
  navigate: (p: Page, id?: number) => void
  onSave: (g: Gear) => void
  onDelete: (id: number) => void
}) {
  const [form, setForm] = useState({ ...gearItem })
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [showStatusConfirm, setShowStatusConfirm] = useState(false)
  const [pendingStatus, setPendingStatus] = useState<GearStatus>(gearItem.status)
  const [success, setSuccess] = useState(false)

  const handleStatusChange = (status: GearStatus) => {
    if (status === 'Inactive' && form.status !== 'Inactive') {
      setPendingStatus(status)
      setShowStatusConfirm(true)
    } else {
      setForm({ ...form, status })
    }
  }

  const confirmStatusChange = () => {
    setForm({ ...form, status: pendingStatus })
    setShowStatusConfirm(false)
  }

  const handleSave = () => {
    onSave(form)
    setSuccess(true)
    setTimeout(() => navigate('gear'), 1500)
  }

  const handleDelete = () => {
    onDelete(gearItem.id)
    navigate('gear')
  }

  if (success) {
    return (
      <div className="max-w-sm mx-auto mt-20 bg-white border border-gray-200 rounded-xl p-8 text-center shadow-sm">
        <div className="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 text-green-600 text-2xl">✓</div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">Gear Updated!</h2>
        <p className="text-sm text-gray-500">{form.name} has been updated.</p>
        <button
          onClick={() => navigate('gear')}
          className="mt-4 bg-green-700 hover:bg-green-800 text-white text-sm font-medium px-5 py-2 rounded transition-colors cursor-pointer"
        >
          View Gear Inventory
        </button>
      </div>
    )
  }

  return (
    <div className="max-w-xl">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Edit Gear</h1>

      <div className="bg-white border border-gray-200 rounded-lg p-6 space-y-4">
        <div className="flex items-center gap-4 pb-4 border-b border-gray-100">
          <div className="w-16 h-16 bg-green-50 rounded-lg border border-green-100 flex items-center justify-center">
            <TentIllustration size={48} />
          </div>
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">Name *</div>
            <input
              type="text"
              value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
              className="border border-gray-200 rounded px-3 py-1.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-green-300"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Category *</label>
            <select
              value={form.category}
              onChange={e => setForm({ ...form, category: e.target.value })}
              className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300 bg-white"
            >
              <option>Camping</option>
              <option>Hiking</option>
              <option>Water Sports</option>
              <option>Cooking</option>
              <option>Climbing</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Size</label>
            <input
              type="text"
              value={form.size}
              onChange={e => setForm({ ...form, size: e.target.value })}
              className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
          <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Purchase Date</label>
          <input
            type="text"
            value={form.purchaseDate}
            onChange={e => setForm({ ...form, purchaseDate: e.target.value })}
            className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
          />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Access</label>
            <select
              value={form.access}
              onChange={e => setForm({ ...form, access: e.target.value as AccessLevel })}
              className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300 bg-white"
            >
              <option>Everyone</option>
              <option>Staff only</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Condition</label>
            <select
              value={form.condition}
              onChange={e => setForm({ ...form, condition: e.target.value })}
              className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300 bg-white"
            >
              <option>Excellent</option>
              <option>Good</option>
              <option>Fair</option>
              <option>Needs Repair</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Status *</label>
            <select
              value={form.status}
              onChange={e => handleStatusChange(e.target.value as GearStatus)}
              className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300 bg-white"
            >
              <option>Available</option>
              <option>Rented</option>
              <option>Maintenance</option>
              <option>Inactive</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Description</label>
          <textarea
            value={form.description}
            onChange={e => setForm({ ...form, description: e.target.value })}
            rows={3}
            className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300 resize-none"
          />
        </div>
      </div>

      <div className="flex gap-3 mt-5">
        <button
          onClick={() => navigate('gear')}
          className="border border-gray-300 hover:border-gray-400 text-gray-700 text-sm font-medium px-5 py-2.5 rounded transition-colors cursor-pointer"
        >
          Cancel
        </button>
        <button
          onClick={() => setShowDeleteConfirm(true)}
          className="border border-red-300 hover:bg-red-50 text-red-600 text-sm font-medium px-5 py-2.5 rounded transition-colors cursor-pointer"
        >
          Delete Gear
        </button>
        <button
          onClick={handleSave}
          className="bg-green-700 hover:bg-green-800 text-white text-sm font-medium px-5 py-2.5 rounded transition-colors cursor-pointer ml-auto"
        >
          Save Changes
        </button>
      </div>

      {showStatusConfirm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600 text-xl">⚠</div>
              <button onClick={() => setShowStatusConfirm(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer">✕</button>
            </div>
            <h3 className="font-bold text-gray-900 mb-2">Change Gear Status?</h3>
            <p className="text-sm text-gray-600 mb-5">
              Are you sure you want to mark <strong>{form.name}</strong> as Inactive?
              <br /><br />
              This item will no longer appear in the available gear list and cannot be selected for new rentals.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowStatusConfirm(false)}
                className="flex-1 border border-gray-300 text-gray-700 text-sm font-medium py-2 rounded hover:bg-gray-50 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={confirmStatusChange}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white text-sm font-medium py-2 rounded transition-colors cursor-pointer"
              >
                Yes, Mark as Inactive
              </button>
            </div>
          </div>
        </div>
      )}

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center text-red-600 text-xl">🗑</div>
              <button onClick={() => setShowDeleteConfirm(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer">✕</button>
            </div>
            <h3 className="font-bold text-gray-900 mb-2">Delete Gear?</h3>
            <p className="text-sm text-gray-600 mb-5">
              Are you sure you want to permanently delete <strong>{form.name}</strong>? This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 border border-gray-300 text-gray-700 text-sm font-medium py-2 rounded hover:bg-gray-50 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white text-sm font-medium py-2 rounded transition-colors cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Page: Users ─────────────────────────────────────────────────────────────
function UsersPage({ users, setUsers }: { users: User[]; setUsers: React.Dispatch<React.SetStateAction<User[]>> }) {
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState<'All' | UserRole>('All')
  const [showAddModal, setShowAddModal] = useState(false)
  const [newUser, setNewUser] = useState({ name: '', email: '', role: 'Student' as UserRole })

  const roles: Array<'All' | UserRole> = ['All', 'Student', 'Staff', 'Admin']

  const filtered = users.filter(u => {
    const matchRole = roleFilter === 'All' || u.role === roleFilter
    const matchSearch = u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase())
    return matchRole && matchSearch
  })

  const toggleStatus = (id: number) => {
    setUsers(prev => prev.map(u => u.id === id
      ? { ...u, status: u.status === 'Active' ? 'Inactive' : 'Active' }
      : u
    ))
  }

  const addUser = () => {
    if (!newUser.name || !newUser.email) return
    setUsers(prev => [...prev, {
      id: Date.now(), name: newUser.name, email: newUser.email,
      role: newUser.role, status: 'Active', rentals: 0, joined: 'Sep 2026'
    }])
    setNewUser({ name: '', email: '', role: 'Student' })
    setShowAddModal(false)
  }

  const roleBadge = (role: UserRole) => {
    const s = { Student: 'bg-blue-50 text-blue-700 border-blue-200', Staff: 'bg-purple-50 text-purple-700 border-purple-200', Admin: 'bg-orange-50 text-orange-700 border-orange-200' }
    return <span className={`inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium border font-mono ${s[role]}`}>{role}</span>
  }

  return (
    <div className="max-w-4xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Users</h1>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-green-700 hover:bg-green-800 text-white text-sm font-medium px-4 py-2 rounded transition-colors cursor-pointer"
        >
          + Add User
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        {(['Student', 'Staff', 'Admin'] as UserRole[]).map(role => {
          const count = users.filter(u => u.role === role && u.status === 'Active').length
          const colors = { Student: 'bg-blue-50 border-blue-200 text-blue-800', Staff: 'bg-purple-50 border-purple-200 text-purple-800', Admin: 'bg-orange-50 border-orange-200 text-orange-800' }
          return (
            <div key={role} className={`${colors[role]} border rounded-lg p-4 text-center`}>
              <div className="text-2xl font-bold font-mono">{count}</div>
              <div className="text-sm font-medium mt-0.5">{role}s</div>
            </div>
          )
        })}
      </div>

      <div className="bg-white border border-gray-200 rounded-lg">
        <div className="p-4 border-b border-gray-100 flex items-center gap-3 flex-wrap">
          <input
            type="text"
            placeholder="Search name or email..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="border border-gray-200 rounded px-3 py-1.5 text-sm flex-1 min-w-48 focus:outline-none focus:ring-2 focus:ring-green-300"
          />
          <div className="flex gap-1">
            {roles.map(r => (
              <button
                key={r}
                onClick={() => setRoleFilter(r)}
                className={`px-3 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer ${roleFilter === r ? 'bg-green-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>

        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider">
              <th className="text-left px-5 py-3 font-medium">Name</th>
              <th className="text-left px-5 py-3 font-medium">Email</th>
              <th className="text-left px-5 py-3 font-medium">Role</th>
              <th className="text-left px-5 py-3 font-medium">Rentals</th>
              <th className="text-left px-5 py-3 font-medium">Joined</th>
              <th className="text-left px-5 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={6} className="px-5 py-8 text-center text-gray-400">No users found</td></tr>
            ) : filtered.map((u, i) => (
              <tr key={u.id} className={`${i < filtered.length - 1 ? 'border-b border-gray-100' : ''} hover:bg-gray-50 transition-colors`}>
                <td className="px-5 py-3 font-medium text-gray-800">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-green-100 flex items-center justify-center text-green-800 text-xs font-bold">
                      {u.name[0]}
                    </div>
                    {u.name}
                  </div>
                </td>
                <td className="px-5 py-3 text-gray-500 font-mono text-xs">{u.email}</td>
                <td className="px-5 py-3">{roleBadge(u.role)}</td>
                <td className="px-5 py-3 text-gray-600 font-mono text-sm">{u.rentals}</td>
                <td className="px-5 py-3 text-gray-500 text-xs">{u.joined}</td>
                <td className="px-5 py-3">
                  <button
                    onClick={() => toggleStatus(u.id)}
                    className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer ${u.status === 'Active' ? 'bg-green-600' : 'bg-gray-200'}`}
                    title={`Mark as ${u.status === 'Active' ? 'Inactive' : 'Active'}`}
                  >
                    <span className={`inline-block h-3.5 w-3.5 rounded-full bg-white shadow transition-transform ${u.status === 'Active' ? 'translate-x-4.5' : 'translate-x-0.5'}`} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-gray-900 text-lg">Add New User</h3>
              <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer">✕</button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Full Name *</label>
                <input
                  type="text"
                  value={newUser.name}
                  onChange={e => setNewUser({ ...newUser, name: e.target.value })}
                  placeholder="e.g., Jordan T."
                  className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Email *</label>
                <input
                  type="email"
                  value={newUser.email}
                  onChange={e => setNewUser({ ...newUser, email: e.target.value })}
                  placeholder="e.g., user@school.edu"
                  className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Role</label>
                <select
                  value={newUser.role}
                  onChange={e => setNewUser({ ...newUser, role: e.target.value as UserRole })}
                  className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300 bg-white"
                >
                  <option>Student</option>
                  <option>Staff</option>
                  <option>Admin</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setShowAddModal(false)} className="flex-1 border border-gray-300 text-gray-700 text-sm font-medium py-2 rounded hover:bg-gray-50 cursor-pointer">Cancel</button>
              <button onClick={addUser} className="flex-1 bg-green-700 hover:bg-green-800 text-white text-sm font-medium py-2 rounded cursor-pointer">Add User</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Page: Categories ─────────────────────────────────────────────────────────
function CategoriesPage({ categories, setCategories, gear }: { categories: Category[]; setCategories: React.Dispatch<React.SetStateAction<Category[]>>; gear: Gear[] }) {
  const [showAddModal, setShowAddModal] = useState(false)
  const [editingId, setEditingId] = useState<number | null>(null)
  const [form, setForm] = useState({ name: '', description: '', icon: '📦', subcategories: '' })
  const [deleteId, setDeleteId] = useState<number | null>(null)

  const openAdd = () => {
    setForm({ name: '', description: '', icon: '📦', subcategories: '' })
    setEditingId(null)
    setShowAddModal(true)
  }

  const openEdit = (cat: Category) => {
    setForm({ name: cat.name, description: cat.description, icon: cat.icon, subcategories: cat.subcategories.join(', ') })
    setEditingId(cat.id)
    setShowAddModal(true)
  }

  const saveCategory = () => {
    if (!form.name) return
    if (editingId) {
      setCategories(prev => prev.map(c => c.id === editingId ? { ...c, ...form, subcategories: form.subcategories.split(',').map(s => s.trim()).filter(Boolean) } : c))
    } else {
      setCategories(prev => [...prev, { id: Date.now(), ...form, subcategories: form.subcategories.split(',').map(s => s.trim()).filter(Boolean), itemCount: 0 }])
    }
    setShowAddModal(false)
  }

  const confirmDelete = () => {
    if (deleteId) setCategories(prev => prev.filter(c => c.id !== deleteId))
    setDeleteId(null)
  }

  const gearCountForCategory = (name: string) => gear.filter(g => g.category === name).length

  return (
    <div className="max-w-3xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Categories</h1>
        <button
          onClick={openAdd}
          className="flex items-center gap-2 bg-green-700 hover:bg-green-800 text-white text-sm font-medium px-4 py-2 rounded transition-colors cursor-pointer"
        >
          + Add Category
        </button>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {categories.map(cat => {
          const liveCount = gearCountForCategory(cat.name)
          return (
            <div key={cat.id} className="bg-white border border-gray-200 rounded-lg px-5 py-4 flex items-center gap-4 hover:border-green-200 transition-colors">
              <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center text-2xl shrink-0">
                {cat.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-gray-900">{cat.name}</div>
                <div className="text-sm text-gray-500 truncate">{cat.description}</div>
                <div className="flex gap-1.5 mt-2 flex-wrap">
                  {cat.subcategories.map(sub => (
                    <span key={sub} className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">{sub}</span>
                  ))}
                </div>
              </div>
              <div className="text-center shrink-0">
                <div className="text-xl font-bold text-green-700 font-mono">{liveCount || cat.itemCount}</div>
                <div className="text-xs text-gray-400">items</div>
              </div>
              <div className="flex gap-2 shrink-0">
                <button
                  onClick={() => openEdit(cat)}
                  className="text-xs border border-gray-200 hover:border-gray-400 text-gray-600 hover:text-gray-800 px-3 py-1.5 rounded transition-colors cursor-pointer"
                >
                  Edit
                </button>
                <button
                  onClick={() => setDeleteId(cat.id)}
                  className="text-xs border border-red-200 hover:bg-red-50 text-red-500 px-3 py-1.5 rounded transition-colors cursor-pointer"
                >
                  Delete
                </button>
              </div>
            </div>
          )
        })}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-gray-900 text-lg">{editingId ? 'Edit Category' : 'Add Category'}</h3>
              <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer">✕</button>
            </div>
            <div className="space-y-4">
              <div className="flex gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Icon</label>
                  <input
                    type="text"
                    value={form.icon}
                    onChange={e => setForm({ ...form, icon: e.target.value })}
                    className="w-14 border border-gray-200 rounded px-2 py-2 text-lg text-center focus:outline-none focus:ring-2 focus:ring-green-300"
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Name *</label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={e => setForm({ ...form, name: e.target.value })}
                    placeholder="e.g., Climbing"
                    className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Description</label>
                <textarea
                  value={form.description}
                  onChange={e => setForm({ ...form, description: e.target.value })}
                  rows={2}
                  placeholder="Brief description of what goes in this category..."
                  className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300 resize-none"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 uppercase tracking-wider mb-1">Subcategories</label>
                <input
                  type="text"
                  value={form.subcategories}
                  onChange={e => setForm({ ...form, subcategories: e.target.value })}
                  placeholder="e.g., Tents, Sleep Systems, Shelter"
                  className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
                />
                <p className="text-xs text-gray-400 mt-1">Separate subcategories with commas.</p>
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setShowAddModal(false)} className="flex-1 border border-gray-300 text-gray-700 text-sm font-medium py-2 rounded hover:bg-gray-50 cursor-pointer">Cancel</button>
              <button onClick={saveCategory} className="flex-1 bg-green-700 hover:bg-green-800 text-white text-sm font-medium py-2 rounded cursor-pointer">{editingId ? 'Save Changes' : 'Add Category'}</button>
            </div>
          </div>
        </div>
      )}

      {deleteId !== null && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6">
            <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center text-red-600 text-xl mb-4">🗑</div>
            <h3 className="font-bold text-gray-900 mb-2">Delete Category?</h3>
            <p className="text-sm text-gray-600 mb-5">This will remove the category. Existing gear items in this category will be unaffected.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteId(null)} className="flex-1 border border-gray-300 text-gray-700 text-sm font-medium py-2 rounded hover:bg-gray-50 cursor-pointer">Cancel</button>
              <button onClick={confirmDelete} className="flex-1 bg-red-600 hover:bg-red-700 text-white text-sm font-medium py-2 rounded cursor-pointer">Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Page: Reports ────────────────────────────────────────────────────────────
function ReportsPage({ rentals, gear, users }: { rentals: Rental[]; gear: Gear[]; users: User[] }) {
  const [activeTab, setActiveTab] = useState<'overview' | 'rentals' | 'gear' | 'donors'>('overview')

  const totalRentals = rentals.length
  const activeRentals = rentals.filter(r => r.status === 'Active').length
  const overdueRentals = rentals.filter(r => r.status === 'Overdue').length
  const returnedRentals = rentals.filter(r => r.status === 'Returned').length
  const availableGear = gear.filter(g => g.status === 'Available').length
  const rentedGear = gear.filter(g => g.status === 'Rented').length
  const activeUsers = users.filter(u => u.status === 'Active').length
  const averageDuration = Math.round((rentals.reduce((sum, rental) => sum + rental.durationDays, 0) / Math.max(rentals.length, 1)) * 10) / 10
  const uniqueRentalTypes = new Set(rentals.map(r => itemType(r.gear))).size
  const rentalTypeCounts = Array.from(new Set(gear.map(g => itemType(g.name)))).map(name => ({
    name,
    count: rentals.filter(r => itemType(r.gear) === name).length,
    category: gear.find(g => itemType(g.name) === name)?.category ?? '—',
  })).sort((a, b) => b.count - a.count)
  const leastRented = [...rentalTypeCounts].sort((a, b) => a.count - b.count).slice(0, 4)
  const tentSizeDemand = Array.from(new Set(gear.filter(g => itemType(g.name) === 'Tent').map(g => g.size))).map(size => ({
    size,
    rentals: rentals.filter(r => {
      const rentedGear = gear.find(g => g.name === r.gear)
      return itemType(r.gear) === 'Tent' && rentedGear?.size === size
    }).length,
  })).sort((a, b) => b.rentals - a.rentals)
  const donors = [
    { name: 'Alpine Community Fund', type: 'Grant', contribution: '$12,500', items: 0, lastGift: 'Aug 28, 2026' },
    { name: 'Trailhead Outfitters', type: 'Gear', contribution: '$8,400', items: 18, lastGift: 'Aug 12, 2026' },
    { name: 'North Valley Alumni', type: 'Campaign', contribution: '$6,250', items: 0, lastGift: 'Jul 30, 2026' },
    { name: 'Summit Club', type: 'Gear', contribution: '$3,100', items: 9, lastGift: 'Jul 18, 2026' },
  ]

  const statusBreakdown: { label: RentalStatus; count: number; color: string }[] = [
    { label: 'Trip Reserved', count: rentals.filter(r => r.status === 'Trip Reserved').length, color: 'bg-purple-500' },
    { label: 'Active', count: activeRentals, color: 'bg-green-500' },
    { label: 'Due Soon', count: rentals.filter(r => r.status === 'Due Soon').length, color: 'bg-yellow-400' },
    { label: 'Overdue', count: overdueRentals, color: 'bg-red-500' },
    { label: 'Returned', count: returnedRentals, color: 'bg-gray-300' },
  ]

  const gearStatusBreakdown: { label: GearStatus; count: number; color: string }[] = [
    { label: 'Available', count: availableGear, color: 'bg-green-500' },
    { label: 'Rented', count: rentedGear, color: 'bg-yellow-400' },
    { label: 'Maintenance', count: gear.filter(g => g.status === 'Maintenance').length, color: 'bg-blue-400' },
    { label: 'Inactive', count: gear.filter(g => g.status === 'Inactive').length, color: 'bg-gray-300' },
  ]

  const BarChart = ({ data }: { data: { label: string; count: number; color: string }[] }) => {
    const max = Math.max(...data.map(d => d.count), 1)
    return (
      <div className="space-y-3">
        {data.map(d => (
          <div key={d.label} className="flex items-center gap-3">
            <div className="w-24 text-xs text-gray-500 text-right shrink-0">{d.label}</div>
            <div className="flex-1 bg-gray-100 rounded-full h-5 overflow-hidden">
              <div
                className={`${d.color} h-full rounded-full transition-all duration-500 flex items-center justify-end pr-2`}
                style={{ width: `${(d.count / max) * 100}%` }}
              >
                {d.count > 0 && <span className="text-xs text-white font-mono font-medium">{d.count}</span>}
              </div>
            </div>
            {d.count === 0 && <span className="text-xs text-gray-400 font-mono">0</span>}
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Reports</h1>

      <div className="flex gap-1 mb-6 bg-gray-100 rounded-lg p-1 w-fit">
        {(['overview', 'rentals', 'gear', 'donors'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-1.5 rounded-md text-sm font-medium capitalize transition-colors cursor-pointer ${activeTab === tab ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
            {[
              { label: 'Total Rentals', value: totalRentals, sub: 'all time' },
              { label: 'Unique Items', value: uniqueRentalTypes, sub: 'gear types rented' },
              { label: 'Avg. Duration', value: `${averageDuration}d`, sub: 'per rental' },
              { label: 'Active Now', value: activeRentals, sub: 'currently out' },
              { label: 'Active Users', value: activeUsers, sub: 'registered' },
            ].map(s => (
              <div key={s.label} className="bg-white border border-gray-200 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold font-mono text-gray-900">{s.value}</div>
                <div className="text-xs font-semibold text-gray-700 mt-1">{s.label}</div>
                <div className="text-xs text-gray-400">{s.sub}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-5">
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <h3 className="font-semibold text-gray-800 mb-4 text-sm uppercase tracking-wider">Rental Status</h3>
              <BarChart data={statusBreakdown} />
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <h3 className="font-semibold text-gray-800 mb-4 text-sm uppercase tracking-wider">Gear Status</h3>
              <BarChart data={gearStatusBreakdown} />
            </div>
          </div>
        </div>
      )}

      {activeTab === 'rentals' && (
        <div className="space-y-5">
          <div className="bg-white border border-gray-200 rounded-lg p-5">
            <h3 className="font-semibold text-gray-800 mb-4 text-sm uppercase tracking-wider">Rental Status Breakdown</h3>
            <BarChart data={statusBreakdown} />
          </div>

          <div className="bg-white border border-gray-200 rounded-lg">
            <div className="px-5 py-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800 text-sm uppercase tracking-wider">All Rentals</h3>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider">
                  <th className="text-left px-5 py-3 font-medium">Student</th>
                  <th className="text-left px-5 py-3 font-medium">Gear</th>
                  <th className="text-left px-5 py-3 font-medium">Due</th>
                  <th className="text-left px-5 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {rentals.map((r, i) => (
                  <tr key={r.id} className={i < rentals.length - 1 ? 'border-b border-gray-100' : ''}>
                    <td className="px-5 py-3 font-medium text-gray-800">{r.student}</td>
                    <td className="px-5 py-3 text-gray-600">{r.gear}</td>
                    <td className="px-5 py-3 text-gray-500 font-mono text-xs">{r.dueDate}</td>
                    <td className="px-5 py-3"><RentalBadge status={r.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'gear' && (
        <div className="space-y-5">
          <div className="bg-white border border-gray-200 rounded-lg p-5">
            <h3 className="font-semibold text-gray-800 mb-4 text-sm uppercase tracking-wider">Gear Status Breakdown</h3>
            <BarChart data={gearStatusBreakdown} />
          </div>

          <div className="bg-white border border-gray-200 rounded-lg">
            <div className="px-5 py-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800 text-sm uppercase tracking-wider">Most Rented Gear Types</h3>
              <p className="text-xs text-gray-400 mt-1">Grouped by item type rather than inventory ID.</p>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider">
                  <th className="text-left px-5 py-3 font-medium">Item</th>
                  <th className="text-left px-5 py-3 font-medium">Category</th>
                  <th className="text-left px-5 py-3 font-medium">Times Rented</th>
                </tr>
              </thead>
              <tbody>
                {rentalTypeCounts.map((item, i) => (
                  <tr key={item.name} className={i < rentalTypeCounts.length - 1 ? 'border-b border-gray-100' : ''}>
                    <td className="px-5 py-3 font-medium text-gray-800">{item.name}</td>
                    <td className="px-5 py-3 text-gray-600">{item.category}</td>
                    <td className="px-5 py-3 text-gray-700 font-mono font-medium">{item.count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="grid grid-cols-2 gap-5">
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <h3 className="font-semibold text-gray-800 text-sm uppercase tracking-wider mb-4">Least Frequently Rented</h3>
              <div className="space-y-3">
                {leastRented.map(item => (
                  <div key={item.name} className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">{item.name}</span>
                    <span className="text-xs font-mono text-gray-500">{item.count} rentals</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <h3 className="font-semibold text-gray-800 text-sm uppercase tracking-wider">Tent Size Demand</h3>
              <p className="text-xs text-gray-400 mt-1 mb-4">Use demand by capacity to guide purchasing.</p>
              <div className="space-y-3">
                {tentSizeDemand.map((item, index) => (
                  <div key={item.size} className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">{item.size}</span>
                    <span className={`text-xs font-medium ${index === 0 ? 'text-green-700' : 'text-gray-500'}`}>
                      {item.rentals} rentals{index === 0 ? ' · Buy more' : ''}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'donors' && (
        <div className="space-y-5">
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="text-2xl font-bold font-mono text-gray-900">$30,250</div>
              <div className="text-xs font-semibold text-gray-700 mt-1">Total Support</div>
              <div className="text-xs text-gray-400">estimated value</div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="text-2xl font-bold font-mono text-gray-900">27</div>
              <div className="text-xs font-semibold text-gray-700 mt-1">Gear Donated</div>
              <div className="text-xs text-gray-400">inventory items</div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="text-2xl font-bold font-mono text-gray-900">{donors.length}</div>
              <div className="text-xs font-semibold text-gray-700 mt-1">Active Donors</div>
              <div className="text-xs text-gray-400">this year</div>
            </div>
          </div>
          <div className="bg-white border border-gray-200 rounded-lg">
            <div className="px-5 py-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800 text-sm uppercase tracking-wider">Donor Contributions</h3>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider">
                  <th className="text-left px-5 py-3 font-medium">Donor</th>
                  <th className="text-left px-5 py-3 font-medium">Type</th>
                  <th className="text-left px-5 py-3 font-medium">Value</th>
                  <th className="text-left px-5 py-3 font-medium">Gear Items</th>
                  <th className="text-left px-5 py-3 font-medium">Last Gift</th>
                </tr>
              </thead>
              <tbody>
                {donors.map((donor, index) => (
                  <tr key={donor.name} className={index < donors.length - 1 ? 'border-b border-gray-100' : ''}>
                    <td className="px-5 py-3 font-medium text-gray-800">{donor.name}</td>
                    <td className="px-5 py-3 text-gray-600">{donor.type}</td>
                    <td className="px-5 py-3 text-gray-700 font-mono">{donor.contribution}</td>
                    <td className="px-5 py-3 text-gray-600 font-mono">{donor.items || '—'}</td>
                    <td className="px-5 py-3 text-gray-500 text-xs">{donor.lastGift}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Separate Window: Draft Relational Schema ─────────────────────────────────
type SchemaField = {
  name: string
  type: string
  key?: 'PK' | 'FK'
  note?: string
}

function SchemaTable({
  name, purpose, fields, accent = 'green'
}: {
  name: string
  purpose: string
  fields: SchemaField[]
  accent?: 'green' | 'blue' | 'purple' | 'amber'
}) {
  const accents = {
    green: 'border-t-green-600',
    blue: 'border-t-blue-600',
    purple: 'border-t-purple-600',
    amber: 'border-t-amber-500',
  }

  return (
    <section className={`bg-white border border-gray-200 border-t-4 ${accents[accent]} rounded-lg shadow-sm overflow-hidden`}>
      <div className="px-4 py-3 border-b border-gray-100">
        <h2 className="font-bold text-gray-900 font-mono text-sm uppercase tracking-wide">{name}</h2>
        <p className="text-xs text-gray-500 mt-1">{purpose}</p>
      </div>
      <div className="divide-y divide-gray-100">
        {fields.map(field => (
          <div key={field.name} className="grid grid-cols-[1fr_auto] gap-3 px-4 py-2.5 text-xs">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                {field.key && (
                  <span className={`font-mono font-bold text-[10px] px-1.5 py-0.5 rounded ${
                    field.key === 'PK' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                  }`}>
                    {field.key}
                  </span>
                )}
                <span className="font-mono font-medium text-gray-800">{field.name}</span>
              </div>
              {field.note && <p className="text-gray-400 mt-1 pl-0.5">{field.note}</p>}
            </div>
            <span className="font-mono text-gray-400">{field.type}</span>
          </div>
        ))}
      </div>
    </section>
  )
}

function SchemaPage() {
  const tables: Array<{
    name: string
    purpose: string
    accent: 'green' | 'blue' | 'purple' | 'amber'
    fields: SchemaField[]
  }> = [
    {
      name: 'users',
      purpose: 'Students, staff, and administrators.',
      accent: 'green',
      fields: [
        { name: 'id', type: 'uuid', key: 'PK' },
        { name: 'name', type: 'varchar' },
        { name: 'email', type: 'varchar', note: 'Unique login/contact email' },
        { name: 'role', type: 'enum', note: 'student | staff | admin' },
        { name: 'status', type: 'enum', note: 'active | inactive' },
        { name: 'created_at', type: 'timestamp' },
      ],
    },
    {
      name: 'rentals',
      purpose: 'The transaction connecting a user to a gear item.',
      accent: 'purple',
      fields: [
        { name: 'id', type: 'uuid', key: 'PK' },
        { name: 'user_id', type: 'uuid', key: 'FK', note: '→ users.id' },
        { name: 'gear_id', type: 'uuid', key: 'FK', note: '→ gear.id' },
        { name: 'status', type: 'enum', note: 'reserved | active | due_soon | overdue | returned' },
        { name: 'checkout_date', type: 'date' },
        { name: 'due_date', type: 'date' },
        { name: 'returned_at', type: 'timestamp?' },
        { name: 'access_level', type: 'enum', note: 'everyone | staff_only' },
      ],
    },
    {
      name: 'gear',
      purpose: 'Individual physical inventory records.',
      accent: 'green',
      fields: [
        { name: 'id', type: 'uuid', key: 'PK' },
        { name: 'gear_type_id', type: 'uuid', key: 'FK', note: '→ gear_types.id' },
        { name: 'inventory_code', type: 'varchar', note: 'Example: TENT-014' },
        { name: 'size', type: 'varchar' },
        { name: 'condition', type: 'enum' },
        { name: 'status', type: 'enum' },
        { name: 'access_level', type: 'enum', note: 'everyone | staff_only' },
        { name: 'purchase_date', type: 'date?' },
      ],
    },
    {
      name: 'gear_types',
      purpose: 'Item-level reporting without inventory IDs.',
      accent: 'blue',
      fields: [
        { name: 'id', type: 'uuid', key: 'PK' },
        { name: 'subcategory_id', type: 'uuid', key: 'FK', note: '→ subcategories.id' },
        { name: 'name', type: 'varchar', note: 'Example: Tent, Backpack' },
        { name: 'description', type: 'text?' },
      ],
    },
    {
      name: 'categories',
      purpose: 'Top-level inventory organization.',
      accent: 'blue',
      fields: [
        { name: 'id', type: 'uuid', key: 'PK' },
        { name: 'name', type: 'varchar' },
        { name: 'description', type: 'text?' },
      ],
    },
    {
      name: 'subcategories',
      purpose: 'Nested grouping under a category.',
      accent: 'blue',
      fields: [
        { name: 'id', type: 'uuid', key: 'PK' },
        { name: 'category_id', type: 'uuid', key: 'FK', note: '→ categories.id' },
        { name: 'name', type: 'varchar', note: 'Example: Tents, Sleep Systems' },
      ],
    },
    {
      name: 'donors',
      purpose: 'Organizations and individuals providing support.',
      accent: 'amber',
      fields: [
        { name: 'id', type: 'uuid', key: 'PK' },
        { name: 'name', type: 'varchar' },
        { name: 'email', type: 'varchar?' },
        { name: 'status', type: 'enum' },
        { name: 'created_at', type: 'timestamp' },
      ],
    },
    {
      name: 'donations',
      purpose: 'Cash, grants, campaigns, and donated gear.',
      accent: 'amber',
      fields: [
        { name: 'id', type: 'uuid', key: 'PK' },
        { name: 'donor_id', type: 'uuid', key: 'FK', note: '→ donors.id' },
        { name: 'gear_id', type: 'uuid?', key: 'FK', note: '→ gear.id when an item is donated' },
        { name: 'type', type: 'enum', note: 'cash | grant | campaign | gear' },
        { name: 'estimated_value', type: 'decimal' },
        { name: 'received_at', type: 'date' },
      ],
    },
    {
      name: 'reports',
      purpose: 'Saved report definitions and generated exports.',
      accent: 'purple',
      fields: [
        { name: 'id', type: 'uuid', key: 'PK' },
        { name: 'created_by', type: 'uuid', key: 'FK', note: '→ users.id' },
        { name: 'name', type: 'varchar' },
        { name: 'report_type', type: 'enum', note: 'rentals | gear | donors' },
        { name: 'filters', type: 'jsonb', note: 'Date range, status, size, and access filters' },
        { name: 'generated_at', type: 'timestamp' },
      ],
    },
  ]

  const relations = [
    ['users', '1', 'rentals', 'many', 'A user can have many rentals'],
    ['gear', '1', 'rentals', 'many', 'A gear item appears in many rentals over time'],
    ['categories', '1', 'subcategories', 'many', 'A category contains many subcategories'],
    ['subcategories', '1', 'gear_types', 'many', 'A subcategory contains many item types'],
    ['gear_types', '1', 'gear', 'many', 'An item type has many physical inventory records'],
    ['donors', '1', 'donations', 'many', 'A donor can make many contributions'],
    ['gear', '1', 'donations', 'zero or one', 'A donated item can reference its donation'],
    ['users', '1', 'reports', 'many', 'A user can save or generate many reports'],
  ]

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between gap-4">
          <div>
            <div className="text-xs font-semibold uppercase tracking-widest text-green-700">Outdoor Adventures</div>
            <h1 className="text-xl font-bold mt-1">Draft Relational Data Schema</h1>
            <p className="text-sm text-gray-500 mt-1">Conceptual draft based on the current admin dashboard.</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="border border-gray-300 hover:bg-gray-50 text-gray-700 text-sm font-medium px-4 py-2 rounded cursor-pointer"
            >
              Print draft
            </button>
            <button
              onClick={() => window.close()}
              className="bg-green-700 hover:bg-green-800 text-white text-sm font-medium px-4 py-2 rounded cursor-pointer"
            >
              Close window
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-7 flex flex-wrap gap-x-6 gap-y-2 text-xs text-green-900">
          <span><strong className="font-mono">PK</strong> Primary key</span>
          <span><strong className="font-mono">FK</strong> Foreign key</span>
          <span><strong>?</strong> Optional field</span>
          <span>This is a planning draft, not a database migration.</span>
        </div>

        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5 items-start">
          {tables.map(table => <SchemaTable key={table.name} {...table} />)}
        </div>

        <section className="mt-8 bg-white border border-gray-200 rounded-lg overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100">
            <h2 className="font-bold text-gray-900">Relationship Map</h2>
            <p className="text-sm text-gray-500 mt-1">Cardinality between the proposed tables.</p>
          </div>
          <div className="divide-y divide-gray-100">
            {relations.map(([from, fromCount, to, toCount, description]) => (
              <div key={`${from}-${to}`} className="grid md:grid-cols-[1fr_auto_1fr_2fr] items-center gap-3 px-5 py-3 text-sm">
                <span className="font-mono font-semibold text-gray-800">{from}</span>
                <span className="font-mono text-green-700 bg-green-50 border border-green-100 rounded px-3 py-1">
                  {fromCount} — {toCount}
                </span>
                <span className="font-mono font-semibold text-gray-800">{to}</span>
                <span className="text-gray-500">{description}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-5 bg-purple-50 border border-purple-200 rounded-lg p-5">
          <h2 className="font-bold text-purple-950">Reporting note</h2>
          <p className="text-sm text-purple-900 mt-2 max-w-4xl">
            Dashboard metrics such as average rental duration, most and least rented gear, unique rental types,
            and tent-size demand should be calculated from rentals joined through gear to gear_types. The reports
            table stores saved report settings and exports; it should not duplicate the underlying rental totals.
          </p>
        </section>
      </main>
    </div>
  )
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  if (new URLSearchParams(window.location.search).get('view') === 'schema') {
    return <SchemaPage />
  }

  return <MainApp />
}

function MainApp() {
  const [page, setPage] = useState<Page>('dashboard')
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [rentals, setRentals] = useState<Rental[]>(initialRentals)
  const [gear, setGear] = useState<Gear[]>(initialGear)
  const [users, setUsers] = useState<User[]>(initialUsers)
  const [categories, setCategories] = useState<Category[]>(initialCategories)

  const navigate = (p: Page, id?: number) => {
    setPage(p)
    if (id !== undefined) setSelectedId(id)
  }

  const selectedRental = rentals.find(r => r.id === selectedId)
  const selectedGear = gear.find(g => g.id === selectedId)

  const markReturned = (id: number) => {
    setRentals(prev => prev.map(r => r.id === id ? { ...r, status: 'Returned' } : r))
  }

  const addGear = (g: Omit<Gear, 'id'>) => {
    setGear(prev => [...prev, { ...g, id: Date.now() }])
  }

  const saveGear = (updated: Gear) => {
    setGear(prev => prev.map(g => g.id === updated.id ? updated : g))
  }

  const deleteGear = (id: number) => {
    setGear(prev => prev.filter(g => g.id !== id))
  }

  const renderPage = () => {
    switch (page) {
      case 'dashboard':
        return <DashboardPage rentals={rentals} navigate={navigate} />
      case 'rentals':
        return <RentalsPage rentals={rentals} navigate={navigate} />
      case 'rental-details':
        return selectedRental
          ? <RentalDetailsPage rental={selectedRental} navigate={navigate} onMarkReturned={markReturned} />
          : <RentalsPage rentals={rentals} navigate={navigate} />
      case 'gear':
        return <GearPage gear={gear} navigate={navigate} />
      case 'gear-details':
        return selectedGear
          ? <GearDetailsPage gearItem={selectedGear} navigate={navigate} />
          : <GearPage gear={gear} navigate={navigate} />
      case 'add-gear':
        return <AddGearPage navigate={navigate} onAdd={addGear} />
      case 'edit-gear':
        return selectedGear
          ? <EditGearPage gearItem={selectedGear} navigate={navigate} onSave={saveGear} onDelete={deleteGear} />
          : <GearPage gear={gear} navigate={navigate} />
      case 'users':
        return <UsersPage users={users} setUsers={setUsers} />
      case 'categories':
        return <CategoriesPage categories={categories} setCategories={setCategories} gear={gear} />
      case 'reports':
        return <ReportsPage rentals={rentals} gear={gear} users={users} />
      default:
        return <DashboardPage rentals={rentals} navigate={navigate} />
    }
  }

  return (
    <Layout page={page} navigate={navigate}>
      {renderPage()}
    </Layout>
  )
}
